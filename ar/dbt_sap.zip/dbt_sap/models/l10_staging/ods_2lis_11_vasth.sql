SELECT 'SAP.2lis_11_vasth' data_source_name,  src.*  FROM {{source('sap_sample','2lis_11_vasth')}}  src
