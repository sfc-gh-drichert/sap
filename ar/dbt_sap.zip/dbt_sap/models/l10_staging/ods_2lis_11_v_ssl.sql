SELECT 'SAP.2lis_11_v_ssl' data_source_name,  src.*  FROM {{source('sap_sample','2lis_11_v_ssl')}}  src
