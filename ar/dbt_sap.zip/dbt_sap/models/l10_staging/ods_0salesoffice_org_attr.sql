SELECT 'SAP.0salesoffice_org_attr' data_source_name,  src.*  FROM {{source('sap_sample','0salesoffice_org_attr')}}  src
