SELECT 'SAP.2lis_13_vdhdr' data_source_name,  src.*  FROM {{source('sap_sample','2lis_13_vdhdr')}}  src
