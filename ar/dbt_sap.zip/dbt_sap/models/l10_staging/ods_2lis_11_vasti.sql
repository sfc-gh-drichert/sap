SELECT 'SAP.2lis_11_vasti' data_source_name,  src.*  FROM {{source('sap_sample','2lis_11_vasti')}}  src
