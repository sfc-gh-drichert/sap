SELECT 'SAP.0fi_ar_4' data_source_name,  src.*  FROM {{source('sap_sample','0fi_ar_4')}}  src
