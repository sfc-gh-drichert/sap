SELECT 'SAP.0matl_group_text' data_source_name,  src.*  FROM {{source('sap_sample','0matl_group_text')}}  src
