SELECT 'SAP.2lis_11_vahdr' data_source_name,  src.*  FROM {{source('sap_sample','2lis_11_vahdr')}}  src
