SELECT 'SAP.2lis_12_vchdr' data_source_name,  src.*  FROM {{source('sap_sample','2lis_12_vchdr')}}  src
