SELECT 'SAP.2lis_13_vditm' data_source_name,  src.*  FROM {{source('sap_sample','2lis_13_vditm')}}  src
