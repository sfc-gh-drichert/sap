SELECT 'SAP.0recipcntry_text' data_source_name,  src.*  FROM {{source('sap_sample','0recipcntry_text')}}  src
