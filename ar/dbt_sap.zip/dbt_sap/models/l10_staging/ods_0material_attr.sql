SELECT 'SAP.0material_attr' data_source_name,  src.*  FROM {{source('sap_sample','0material_attr')}}  src
