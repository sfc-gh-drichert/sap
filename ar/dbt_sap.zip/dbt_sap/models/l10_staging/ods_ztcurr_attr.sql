SELECT 'SAP.ztcurr_attr' data_source_name,  src.*  FROM {{source('sap_sample','ztcurr_attr')}}  src
