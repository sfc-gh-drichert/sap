SELECT 'SAP.0sales_off_text' data_source_name,  src.*  FROM {{source('sap_sample','0sales_off_text')}}  src
