SELECT 'SAP.0salesorg_text' data_source_name,  src.*  FROM {{source('sap_sample','0salesorg_text')}}  src
