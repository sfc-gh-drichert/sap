--en_2lis_13_vdkon
SELECT main.* 




FROM {{ref('en_2lis_13_vdkon')}} main

