SELECT *
FROM {{ref('en_2lis_11_v_ssl')}} main
