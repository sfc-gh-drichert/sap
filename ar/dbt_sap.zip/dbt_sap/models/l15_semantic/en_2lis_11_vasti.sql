SELECT
DATA_SOURCE_NAME
, ROCANCEL as rocancel
, BESTA as besta
, FKSAA as fksaa
, FKSTA as fksta
, GBSTA as gbsta
, LFGSA as lfgsa
, LFSTA as lfsta
, POSNR as posnr
, VBELN as billing_document
, VBUK_VBTYP as vbuk_vbtyp
from {{ref('ods_2lis_11_vasti')}}
