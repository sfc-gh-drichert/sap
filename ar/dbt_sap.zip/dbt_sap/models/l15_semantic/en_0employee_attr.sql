SELECT
DATA_SOURCE_NAME
, BEGDA as start_date
, ENDDA as end_date
, PERNR as personnel_number
, RFPNR as rfpnr
, BUKRS as company_code
, WERKS as plant
, BTRTL as btrtl
, PERSG as persg
, PERSK as persk
, ORGEH as orgeh
, STELL as stell
, PLANS as plans
, KOKRS as controlling_area
, KOSTL as cost_center
, ABKRS as abkrs
, MOLGA as molga
, TRFAR as trfar
, TRFGB as trfgb
, TRFKZ as trfkz
, TRFGR as trfgr
, TRFST as trfst
, BSGRD as bsgrd
, ANSAL as ansal
, ANCUR as ancur
, EMPCT as empct
, STAT2 as stat2
, NCSDATE as ncsdate
, SLTYP as sltyp
, SLREG as slreg
, SLGRP as slgrp
, SLLEV as sllev
, ANSVH as ansvh
, VDSK1 as vdsk1
, SNAME as user_name
from {{ref('ods_0employee_attr')}}
