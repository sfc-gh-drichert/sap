SELECT
DATA_SOURCE_NAME
, MATNR as material
, SPRAS as language_key
, TXTMD as txtmd
from {{ref('ods_0material_text')}}
