SELECT
DATA_SOURCE_NAME
, ROCANCEL as rocancel
, VBELN as billing_document
, BUKRS as company_code
, BZIRK as sales_district
, ERDAT as created_on
, FKART as fkart
, FKDAT as fkdat
, FKTYP as fktyp
, HWAER as local_currency
, KDGRP as kdgrp
, KUNAG as kunag
, KUNRG as kunrg
, KURRF as kurrf
, KURST as exchange_rate_type
, PVRTNR as pvrtnr
, STWAE as stwae
, VBTYP as vbtyp
, VKORG as sales_organization
, VTWEG as distrib_channel
, WAERK as waerk
, ANZFK as anzfk
, PERIV as fiscal_year_variant
from {{ref('ods_2lis_13_vdhdr')}}
