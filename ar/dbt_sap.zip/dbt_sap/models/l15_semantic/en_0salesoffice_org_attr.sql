SELECT
DATA_SOURCE_NAME
, VKORG as sales_organization
, VKBUR as vkbur
, VKGRP as vkgrp
, PERNR as personnel_number
from {{ref('ods_0salesoffice_org_attr')}}
