SELECT
--DATA_SOURCE_NAME
MANDT as client
, KUNNR as customer
, TXTMD as txtmd
from {{ref('ods_0customer_text')}}
