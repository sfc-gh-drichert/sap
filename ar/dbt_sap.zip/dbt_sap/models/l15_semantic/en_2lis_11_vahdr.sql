SELECT
DATA_SOURCE_NAME
, ROCANCEL as rocancel
, VBELN as billing_document
, ANGDT as quotation_deadline
, AUART as auart
, AUGRU as augru
, BNDDT as binding_period
, BUKRS as company_code
, ERDAT as created_on
, FAKSK as faksk
, HWAER as local_currency
, KUNNR as customer
, KURST as exchange_rate_type
, KVGR1 as kvgr1
, KVGR2 as kvgr2
, KVGR3 as kvgr3
, KVGR4 as kvgr4
, KVGR5 as kvgr5
, LIFSK as lifsk
, PVRTNR as pvrtnr
, STWAE as stwae
, VBTYP as vbtyp
, VDATU as vdatu
, VKBUR as vkbur
, VKGRP as vkgrp
, VKORG as sales_organization
, VTWEG as distrib_channel
, WAERK as waerk
, SPARA as spara
, VGTYP_AK as vgtyp_ak
, ANZAU as anzau
, PERIV as fiscal_year_variant
from {{ref('ods_2lis_11_vahdr')}}
