SELECT
DATA_SOURCE_NAME
, ROCANCEL as rocancel
, BESTK as bestk
, FKSAK as fksak
, FKSTK as fkstk
, GBSTK as gbstk
, LFGSK as lfgsk
, LFSTK as lfstk
, VBELN as billing_document
, VBTYP as vbtyp
from {{ref('ods_2lis_11_vasth')}}
