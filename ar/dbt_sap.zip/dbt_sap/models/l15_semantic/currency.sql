 Select

client   
, exchange_rate_type   
,   fcurr   
,   tcurr   
,   to_date (substring(to_varchar(99999999 - gdatu),1,8), 'YYYYMMDD')  fxdate   
,   case when MONTH(to_date (substring(to_varchar(99999999 - gdatu),1,8),'YYYYMMDD')) < 10 

then YEAR( to_date(substring(to_varchar(99999999 - gdatu),1,8),'YYYYMMDD'))||'00'||MONTH(to_date (substring(to_varchar(99999999 - gdatu),1,8),'YYYYMMDD')) 

else YEAR( to_date(substring(to_varchar(99999999 - gdatu),1,8),'YYYYMMDD'))||'0'||MONTH(to_date (substring(to_varchar(99999999 - gdatu),1,8),'YYYYMMDD')) 

end as fiscper   
,   ukurs   
,   ffact   
,   tfact  

from 

{{ref ('en_ztcurr_attr')}}
