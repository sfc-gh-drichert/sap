SELECT
DATA_SOURCE_NAME
, VBELN as billing_document
, POSNR as posnr
, ETENR as etenr
, VBELN_VL as vbeln_vl
, POSNR_VL as posnr_vl
, ROCANCEL as rocancel
, WMENG as wmeng
, BMENG as bmeng
, VSMNG as vsmng
, VRKME as vrkme
, LFGSA as lfgsa
, LFSTA as lfsta
, WBSTA as wbsta
, MCEX_WBSTA_LOW as mcex_wbsta_low
, MCEX_W_LFDAT as mcex_w_lfdat
, MCEX_W_LFUHR as mcex_w_lfuhr
, MCEX_B_LFDAT as mcex_b_lfdat
, MCEX_B_LFUHR as mcex_b_lfuhr
, MCEX_B_WADAT as mcex_b_wadat
, MCEX_I_WADAT as mcex_i_wadat
, MCEX_I_WADATLATE as mcex_i_wadatlate
, MCEX_I_LFDAT as mcex_i_lfdat
, MCEX_I_LFUHR as mcex_i_lfuhr
, MCEX_I_LFDATLATE as mcex_i_lfdatlate
, MCEX_I_LFUHRLATE as mcex_i_lfuhrlate
, LIFSP as lifsp
, MEINS as base_unit_of_measure
, UMVKN as umvkn
, UMVKZ as umvkz
, VBTYP as vbtyp
, VBEP_DELETED as vbep_deleted
, RECORD_DELETED as record_deleted
from {{ref('ods_2lis_11_v_ssl')}}
