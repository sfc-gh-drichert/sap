select 
DATA_SOURCE_NAME
, MANDT as client
, KURST as exchange_rate_type
, FCURR as fcurr
, TCURR as tcurr
, GDATU as gdatu
, UKURS as ukurs
, FFACT as ffact
, TFACT as tfact
from {{ref('ods_ztcurr_attr')}}
