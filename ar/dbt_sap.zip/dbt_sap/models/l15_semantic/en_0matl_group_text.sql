SELECT
DATA_SOURCE_NAME
, LANGU as language_key
, KEY1 as key1
, DATETO as dateto
, DATEFROM as datefrom
, TXTSH as txtsh
, TXTMD as txtmd
, TXTLG as txtlg
from {{ref('ods_0matl_group_text')}}
